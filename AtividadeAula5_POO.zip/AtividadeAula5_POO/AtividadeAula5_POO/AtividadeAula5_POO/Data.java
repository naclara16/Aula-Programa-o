import javax.swing.JOptionPane;

public class Data {
    int dia;
    int mes;
    int ano;  

    public Data(){};

    public Data(int d,int m,int a){

    }
    public void CadastraDados(){
        dia = Integer.parseInt(JOptionPane.showInputDialog(null,"Entre com o dia"));
        mes = Integer.parseInt(JOptionPane.showInputDialog(null,"Entre com o mês"));
        ano = Integer.parseInt(JOptionPane.showInputDialog(null,"Entre com o ano"));
    } 
    public void imprimeData(){
        JOptionPane.showMessageDialog(null, this.dia + "/" + this.mes + "/" +this.ano);
    }
}