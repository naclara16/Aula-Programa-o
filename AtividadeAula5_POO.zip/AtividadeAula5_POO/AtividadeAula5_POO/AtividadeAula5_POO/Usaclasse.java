import javax.swing.JOptionPane;

public class Usaclasse {
    public static void main(String[] args) {
        //Triãngulo
        float base;
        float altura;
        float area;
       
        Triangulo tri;

        base = Float.parseFloat(JOptionPane.showInputDialog("Entre com a base do triangulo(Exemp: 3): "));
        altura = Float.parseFloat(JOptionPane.showInputDialog("Entre com a altura do triangulo (Exemp: 5): "));

        tri = new Triangulo(base, altura);
        area = tri.calculaArea();
        tri.imprimeDados();
        JOptionPane.showMessageDialog(null, "Área: " + area);

    //Data
    Data d1;
    d1 = new Data();

    d1.CadastraDados();
    d1.imprimeData();
    }
}