public class Triangulo {
    float base;
    float altura;
    
    Triangulo(){}

    Triangulo(float b, float a){
        base = b;
        altura = a;
    }
}